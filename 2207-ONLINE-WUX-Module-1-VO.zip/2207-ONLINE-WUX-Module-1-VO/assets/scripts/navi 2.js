// 

// ==== Responsive menu ==== //
const responsemenu = document.querySelector(".responsemenu");
const close = document.querySelector(".navi-list .close");
const menu = document.querySelector(".navi-list");

responsemenu.addEventListener("click", () => {
    menu.classList.add("show");
});

close.addEventListener("click", () => {
    menu.classList.remove("show");
});

// ==== Login Form ===== //
const loginForm = document.querySelector("header .wrapper");

document.querySelector(".login").onclick = () => {
    loginForm.classList.add("active");
};

document.querySelector(".close-form").onclick = () => {
    loginForm.classList.remove("active");
};
